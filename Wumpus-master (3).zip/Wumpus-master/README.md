# Wumpus
memes
