﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WumpusProject
{
    public partial class UserInterfaceTest : Form
    {
        public UserInterfaceTest()
        {
            InitializeComponent();
        }
    }
}
