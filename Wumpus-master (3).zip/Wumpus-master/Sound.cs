﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WumpusProject
{
    class Program
    {
        static void Main(string[] args)
        {       
            
        }

        public static bool playSound()
        {
            //play sound here
            //stub
            return true;
        }
    }
}
